plugins {
    id("com.android.application")
}

android {
    namespace = "com.xiujinstore.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.xiujinstore.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
