XIUJIN STORE — PROYEK APK ANDROID

Nama aplikasi: XIUJIN STORE
Application ID: com.xiujinstore.app
Minimum Android: Android 6.0 (API 23)
Tampilan: HTML asli dibungkus di Android WebView.

CARA MEMBANGUN APK:
1. Instal Android Studio di komputer.
2. Ekstrak folder XIUJIN_STORE_Android.
3. Buka folder tersebut melalui Android Studio (Open).
4. Pastikan Android SDK Platform 35 terpasang dan izinkan Gradle Sync mengunduh plugin yang diperlukan.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK debug biasanya tersedia di app/build/outputs/apk/debug/app-debug.apk.

CATATAN:
- Proyek ini menyertakan HTML sebagai assets/index.html, jadi halaman utama dapat dibuka tanpa hosting.
- Font Google dan tautan eksternal membutuhkan internet.
- Ini adalah proyek sumber Android, bukan file APK yang sudah dikompilasi. Lingkungan pembuatan ini tidak memiliki Android SDK/Gradle yang diperlukan untuk menghasilkan dan menguji APK secara langsung.

OPSI BUILD ONLINE (TANPA ANDROID STUDIO DI KOMPUTER SENDIRI):
- Upload/push isi folder proyek ini ke repository GitHub.
- Buka tab Actions pada repository, pilih "Build XIUJIN STORE APK", lalu klik "Run workflow".
- Setelah proses selesai, unduh artifact bernama "XIUJIN-STORE-APK". Artifact tersebut berisi app-debug.apk.
- Langkah ini tetap memerlukan akun GitHub dan repository; file APK tidak dibuat otomatis hanya dengan membuka ZIP.
